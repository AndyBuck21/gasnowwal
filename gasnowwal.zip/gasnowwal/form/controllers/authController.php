<?php

session_start();
require '../config/db.php';

$errors = array();
$username = "";
$email = "";


// if users clicks on the sign up button
if (isset($_POST['signup-btn'])) {
    $fullname = $_POST['fname'];
    $email = $_POST['email'];
    $username = $_POST['uname'];
    $phone = $_POST['pnumber'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];

    // validation
    if (empty($fullname)) {
        $errors['fname'] = "FullName required";

    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Email address is invalid";
    }
    if (empty($email)) {
        $errors['email'] = "Email required";

    }
    if (empty($username)) {
        $errors['uname'] = "UserName required";

    }
    if (empty($phone)) {
        $errors['pnumber'] = "PhoneNumber required";

    }
    if (empty($password)) {
        $errors['pass'] = "Password required";

    }

    if ($password !== $cpassword) {
        $errors['pass'] = "The two password do not match";
    }

    $emailQuery = "SELECT * FROM users WHERE email=? LIMIT 1";
    $stmt = $conn->prepare($emailQuery);
    $stmt->bind_param('s', $email);
    $stnt->execute();
    $result = $stmt->get_result();
    $userCount = $result->num_rows;
    $stmt->close(); 

    if ($userCount > 0) {
        $errors['email'] = "Email already exists"; // Validate Email
    }

    if (count($errors) === 0) {
        $password = password_hash($password, PASSWORD_DEFAULT);
        $token = bin2hex(random_bytes(50));
        $verified = false;

        $sql = "INSERT INTO users (username, email, verified, token, password) VALUES(?, ?, ? ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssbss', $username, $email, $verified, $token, $password);
        
        if ($stnt->execute()) {
            // login user
            $user_id = $conn->insert_id;
            $_SESSION['id'] = $user_id;
            $_SESSION['id'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['verified'] = $verified;
            // set flash message
            $_SESSION['message'] = "Tou are now logged in!";
            header('location: index.php');
            exit(); 
        } else {
            $errors['db_error'] = "Database error failed to register";
        }
    }
}