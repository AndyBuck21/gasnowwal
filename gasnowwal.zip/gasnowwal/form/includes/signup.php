<div class="col-md-6">
              
              <form class="mb-5" method="post" action="signup.php" id="contactForm" name="contactForm">
                <div class="row">
                  <div class="col-md-12 form-group">
                   
               <input type="text" class="form-control" name="fname" id="name" placeholder="Full name" required>
               
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="text" class="form-control" name="email" value="<?php echo $email; ?>" id="email" placeholder="Email" required>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="text" class="form-control" name="uname" id="username"value="<?php echo $username; ?>"placeholder="User Name" required>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="text" class="form-control" name="pnumber" id="pnumber" placeholder="Phone Number" required>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="password" class="form-control" name="pass" id="password" placeholder="Password" required>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="password" class="form-control" name="cpass" id="password" placeholder="Confirm Password" required>
                  </div>
                </div>
                
               
                <div class="row">
                  <div class="col-12">
                    <input type="submit" value="Sign Up" name="signup-btn" class="btn btn-primary rounded-0 py-2 px-4">
                  <span class="submitting"></span>
                  </div>
                </div>
              </form>

              <div id="form-message-warning mt-4"></div> 
              <div id="form-message-success">
                Account created successfully!
              </div>
            <center>          
                <a href="signin.php"> Have an account? Sign In</a>
                <br>
                <a href="../index.php"> Back to home</a>
            </center>
            </div>