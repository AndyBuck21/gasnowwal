<div class="col-md-6">
              
              <form class="mb-5" method="post" action="" id="contactForm" name="contactForm">
                <div class="row">
                  
                </div>
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="text" class="form-control" name="email" id="email" placeholder="Email" required>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-md-12 form-group">
                    <input type="password" class="form-control" name="pass" id="password" placeholder="Password" required>
                  </div>
                </div>
                
               
                <div class="row">
                  <div class="col-12">
                    <input type="submit" value="Log In" class="btn btn-primary rounded-0 py-2 px-4">
                  <span class="submitting"></span>
                  </div>
                </div>
              </form>

              <div id="form-message-warning mt-4"></div> 
              <div id="form-message-success">
                Log In  successfully!
              </div>
            <center> 
                <a href="?forget_pass"> Forgot Password?</a> 
                <br>       
                <a href="signup.php"> Don't have an account? Sign Up</a>
                <br>
                <a href="../index.php"> Back to Home</a>
            </center>
            </div>