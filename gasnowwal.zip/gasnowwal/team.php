<!DOCTYPE html>

<html lang="en">
<?php include_once('includes/header.php') ?>

 <!-- Collect the nav links, forms, and other content for toggling -->
 <div class="collapse navbar-collapse" id="navigation-nav">
          <ul class="nav navbar-nav navbar-right">
            <li><a class="section-scroll" href="index.php">Home</a></li>
            <li class="active"><a href="team.php">Team</a></li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container -->
    </nav>
  </header>
  <!-- End Navbar -->



  <div id="wrapper">

 

   

    <section>
      <div class="sep-section"></div>
    </section>

    

    
   
   

    <!-- Team
    ================================================== -->
    <section>
      <div id="team-section" class="pad-sec">
        <div class="container">
          <div class="title-section animated out" data-animation="fadeInUp" data-delay="0">
            <div class="row">
              <div class="col-sm-8 col-sm-offset-2">
                <h2>Meet our awesome team</h2>
                <hr>
                
              </div>
            </div> <!-- End row -->
          </div> <!-- end title-section -->

          <div class="team-members">
            <div class="row">

              <!-- member-team -->
              <div class="col-sm-4">
                <div class="member-team animated out" data-animation="fadeInLeft" data-delay="0">
                  <img src="assets/images/team/ben.jpg" alt="" height="500px">
                  <div class="magnifier">
                    <div class="magnifier-inner">
                      <h3>Bernard Torlafia </h3>
                      <p>Founder &amp; (CEO)</p>
                      <p>Bernard Torlafia is a digital entrepremeur, a business executive who has 4years
                    working experience with NNPC retail.. While working there Bernard discovered that swapping
                    systems for cooking gas still had a system challenge because payment and access were still
                     a challenge within the sector.</p>
                      <ul class="social-icons">

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Facebook" href="#" data-original-title="" title=""><i class="fa fa-facebook"></i></a></li>

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Twitter" href="#" data-original-title="" title=""><i class="fa fa-twitter"></i></a></li>

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Instagram" href="#" data-original-title="" title=""><i class="fa fa-instagram"></i></a></li>

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Linkedin" href="#" data-original-title="" title=""><i class="fa fa-linkedin"></i></a></li>

                      </ul>
                    </div> <!-- End magnifier-inner -->
                  </div> <!-- End magnifier -->
                </div> <!-- End member-team -->
              </div> <!-- End col-sm-4 -->

              <!-- member-team -->
              <div class="col-sm-4">
                <div class="member-team animated out" data-animation="fadeInUp" data-delay="0">
                  <img src="assets/images/team/k.jpg" alt="" height="500px">
                  <div class="magnifier">
                    <div class="magnifier-inner">
                      <h3>Jude Iwuchukwu</h3>
                      <p>Growth Management officer</p>
                      <p>Jude Iwuchukwu is a certified industrial chemist, Entrepreneur, an Instructor and human capacity developer.
                    He is a highly motivated team leader in the workplace. Able to communicate organizational goals
                     so that everyone understand them and their role in achieving them.</p>
                      <ul class="social-icons">

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Facebook" href="#" data-original-title="" title=""><i class="fa fa-facebook"></i></a></li>

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Twitter" href="#" data-original-title="" title=""><i class="fa fa-twitter"></i></a></li>

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Instagram" href="#" data-original-title="" title=""><i class="fa fa-instagram"></i></a></li>

                        <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Linkedin" href="#" data-original-title="" title=""><i class="fa fa-linkedin"></i></a></li>

                      </ul>
                    </div> <!-- End magnifier-inner -->
                  </div> <!-- End magnifier -->
                </div> <!-- End member-team -->
              </div> <!-- End col-sm-4 -->

              <!-- member-team -->
              <div class="col-sm-4">
                <div class="member-team animated out" data-animation="fadeInRight" data-delay="0">
                  <img src="assets/images/team/j.jpg" alt="" height="500px">
                  <div class="magnifier">
                    <div class="magnifier-inner">
                      <h3>Mercy Tydough</h3>
                      <p>Lead generation officer</p>
                      <p>Mercy is a customer relationship manager, she over see customer on-boarding, client retention
                     and engagement. She has over 3years experience, a graduate of FUAM Benue state.</p>
                      <ul class="social-icons">

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Facebook" href="#" data-original-title="" title=""><i class="fa fa-facebook"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Twitter" href="#" data-original-title="" title=""><i class="fa fa-twitter"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Instagram" href="#" data-original-title="" title=""><i class="fa fa-instagram"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Linkedin" href="#" data-original-title="" title=""><i class="fa fa-linkedin"></i></a></li>

                      </ul>
                    </div> <!-- End magnifier-inner -->
                  </div> <!-- End magnifier -->
                </div> <!-- End member-team -->
              </div> <!-- End col-sm-4 -->

              <!-- member-team -->
              <div class="col-sm-4">
                <div class="member-team animated out" data-animation="fadeInRight" data-delay="0">
                  <img src="assets/images/team/ti.jpeg" alt="" height="500px">
                  <div class="magnifier">
                    <div class="magnifier-inner">
                    <h3>Titus Nyiakaa</h3>
                      <p>CFO</p>
                      <p>Titus Nyiakaa is a certified finance and Investment manager with core banking experience in retail
                     banking with Stanbic IBTC and FMCG industry. He is a professional accountant with 10years experience.</p>
                      <ul class="social-icons">

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Facebook" href="#" data-original-title="" title=""><i class="fa fa-facebook"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Twitter" href="#" data-original-title="" title=""><i class="fa fa-twitter"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Instagram" href="#" data-original-title="" title=""><i class="fa fa-instagram"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Linkedin" href="#" data-original-title="" title=""><i class="fa fa-linkedin"></i></a></li>

                      </ul>
                    </div> <!-- End magnifier-inner -->
                  </div> <!-- End magnifier -->
                </div> <!-- End member-team -->
              </div> <!-- End col-sm-4 -->

              <!-- member-team -->
              <div class="col-sm-4">
                <div class="member-team animated out" data-animation="fadeInRight" data-delay="0">
                  <img src="assets/images/team//suzy.jpeg" alt="" height="500px">
                  <div class="magnifier">
                    <div class="magnifier-inner">
                      <h3>Susan Aricoke </h3>
                      <p>COO</p>
                      <p>Susan Arichoke is a business executive with over 5 years experience in strategic business management.
                     In 2019, she founded Hikitchen, a food-tech startup for working moms and busy professionals.</p>
                      <ul class="social-icons">

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Facebook" href="#" data-original-title="" title=""><i class="fa fa-facebook"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Twitter" href="#" data-original-title="" title=""><i class="fa fa-twitter"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Instagram" href="#" data-original-title="" title=""><i class="fa fa-instagram"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Linkedin" href="#" data-original-title="" title=""><i class="fa fa-linkedin"></i></a></li>

                      </ul>
                    </div> <!-- End magnifier-inner -->
                  </div> <!-- End magnifier -->
                </div> <!-- End member-team -->
              </div> <!-- End col-sm-4 -->
              <!-- member-team -->
              <div class="col-sm-4">
                <div class="member-team animated out" data-animation="fadeInRight" data-delay="0">
                  <img src="assets/images/team/bet.jpeg" alt="" height="500px">
                  <div class="magnifier">
                    <div class="magnifier-inner">
                      <h3>Betsy Nunoo</h3>
                      <p>HR. Lead & Talent Manager</p>
                      <p>Betsy Nunoo is a software engineer (front end/UI,UX designer). She is a  
                    graduate of Nwame Nkruma University of Science & Technology, Ghana.</p>
                      <ul class="social-icons">

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Facebook" href="#" data-original-title="" title=""><i class="fa fa-facebook"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Twitter" href="#" data-original-title="" title=""><i class="fa fa-twitter"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Instagram" href="#" data-original-title="" title=""><i class="fa fa-instagram"></i></a></li>

                      <li><a data-rel="tooltip" data-toggle="tooltip" data-trigger="hover" data-placement="bottom" data-title="Linkedin" href="#" data-original-title="" title=""><i class="fa fa-linkedin"></i></a></li>

                      </ul>
                    </div> <!-- End magnifier-inner -->
                  </div> <!-- End magnifier -->
                </div> <!-- End member-team -->
              </div> <!-- End col-sm-4 -->

            </div>
          </div> <!-- End team-members -->
        </div> <!-- End container -->
      </div> <!-- End team-section -->
    </section>
    <!-- End team section -->



    
    

    <section>
      <div class="sep-section"></div>
    </section>

<?php include_once('includes/footer.php') ?>

    
   
    
</html>